from turtle import  Turtle


class Paddle(Turtle):
    def __init__(self,position):
        super().__init__()
        self.shape("square")
        self.color("Blue")
        self.penup()
        self.goto(position)

    def go_right(self):
        new_x=self.xcor() + 20
        self.goto(new_x,self.ycor())

    def go_left(self):
        new_x=self.xcor() - 20
        self.goto(new_x,self.ycor())


