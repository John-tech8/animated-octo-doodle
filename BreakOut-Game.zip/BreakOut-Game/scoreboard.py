from turtle import Turtle


class ScoreBoard(Turtle):
    def __init__(self):
        super().__init__()

        self.score=0
        self.penup()
        self.color("white")
        self.hideturtle()
        self.update_scoreboard()


    def update_scoreboard(self):
        self.clear()
        self.goto(-100,200)
        self.write(f"Score: {self.score}",align="center",font=("Courier",24,"bold"))


    def point(self):
        self.score+=1
        self.update_scoreboard()