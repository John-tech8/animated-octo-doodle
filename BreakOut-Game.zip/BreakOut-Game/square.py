from turtle import Turtle


class square(Turtle):
    def __init__(self):
        super().__init__()

        self.shape("square")
        self.color("blue")
        self.penup()
        self.x_move=3
        self.y_move=3
        self.move_speed=0.1



    def move(self):
        new_x=self.xcor() + self.x_move
        new_y=self.ycor() + self.y_move

        self.goto(new_x,new_y)

    def bounce_x(self):
        self.x_move *= -1
        self.move_speed *=0.9

    def bounce_y(self):
        self.y_move *= -1

    def reset_position(self):
        self.goto(0,0)
        self.move_speed=0
        self.bounce_x()