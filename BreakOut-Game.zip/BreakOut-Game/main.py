from turtle import Turtle,Screen
from paddle import Paddle


import paddle

screen = Screen()
screen.setup(width=800,height=600)
screen.bgcolor("black")




screen.title("Break Out")
screen.tracer(0)




screen.listen()
screen.onkey(paddle.go_right,"Right")
screen.onkey(paddle.go_left,"Left")